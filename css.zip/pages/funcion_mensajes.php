<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="../css/estilos_confirmar.css">
</head>
<body>
	<section class="main">
		<div id="openModalm" class="modalDialogom">
			<div>
				<a href="#closem" title="cerrar" class="cerrarm">X</a>
				<section class="logm">
					<div id="titulo_vent">
						Muchas Gracias por Contactarnos!
					</div>
					<div id="mensaje">
						En breve nos estaremos poniendo en contacto contigo a traves del numero telefono o el correo electronico que nos proporcionaste.
					</div>
					<div id="btnsalir">
						<a href="#closem" class="btTxtm">Aceptar</a>	
					</div>	
				</section>
			</div>
		</div>
	</section>
</body>
</html>
