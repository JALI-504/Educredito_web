<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
	<link rel="stylesheet" href="css/estilos_confirmar.css">
	<link rel="stylesheet" href="../css/estilos_confirmar.css">
</head>
<body>
	<section class="main">
		<div id="openModalm" class="modalDialogom">
			<div>
				<a href="#closem" title="cerrar" class="cerrarm">X</a>
				<section class="logm">
					<div id="titulo_vent">
						Muchas Gracias por Contactarnos!
					</div>
					<div id="mensaje">
						Pronto te estaremos enviando la información necesaria al correo que nos proporcionaste para que puedas informarte mas sobre nuestros servicios.</br> Recuerda ir a tu correo y revisarlo.
					</div>
					<div id="btnsalir">
						<a href="#closem" class="btTxtm">Aceptar</a>	
					</div>	
				</section>
			</div>
		</div>
	</section>
</body>
</html>
