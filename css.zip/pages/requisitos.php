	
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;">
	<link rel="shortcut icon" type="image/png" href="../images/favicon.png"/>
	<title>Instituto de Credito Educativo | Requisitos</title>
	<link rel="stylesheet" href="../css/style_requisitos.css">
	<link rel="stylesheet" href="../css/fonts.css">
	<script type="text/javascript" src="../js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript">
		$(document).ready(main);
 
		var contador = 1;
		 
		function main () {
			$('.menu_bar').click(function(){
				if (contador == 1) {
					$('nav').animate({
						left: '0'
					});
					contador = 0;
				} else {
					contador = 1;
					$('nav').animate({
						left: '-150%'
					});
				}
			});
		 
			// Mostramos y ocultamos submenus
			$('.submenu').click(function(){
				$(this).children('.children').slideToggle();
			});
		}

	</script>
</head>
<body>
	<header>
		<div class="menu_bar">
			<a href="#" class="bt-menu"><span class="icon-menu"></span>Menú</a>
		</div>
 
		<nav>
			<div id="mencenter">
				
				<ul>
					<li><a href="../"><span class="icon-home"></span>Inicio</a></li>
					<li><a href="#"><span class="icon-point-right"></span>Nosotros</a></li>
					<li><a href="financiamiento.php"><span class="icon-coin-dollar"></span>Financiamiento</a></li>
					<li><a href="requisitos.php"><span class="icon-files-empty"></span>Requisitos</a></li>
					<li><a href="financiamiento.php#calculate"><span class="icon-calculator"></span>Calcular</a></li>
					<li><a href="faqs.php"><span class="icon-question"></span>Faqs</a></li>
					<li><a href="#"><span class="icon-library"></span>Convenios</a></li>
					<li><a href="#"><span class="icon-profile"></span>Becas</a></li>
					<li><a href="contactenos.php"><span class="icon-phone"></span>Contacto</a></li>
				</ul>
			</div>
		</nav>
	</header>
	<div class="wrapper">
		<section id="portada">
			<div id="bienvenida">
				<div id="contenido">
					<div id="titulos">
						<div id="titu">
							FINANCIAMOS TU EDUCACIÓN UNIVERSITARIA
						</div>
						<p>Tenemos las soluciones que los estudiantes necesitan para no abandonar sus estudios y metas profesionales.</p>
					</div>
					<div id="btn_email">
						<a href="../webmail" target="_blank" title="">Email de Empleados</a>
					</div>
				</div>
				<div id="img_edu">
					<img src="../images/logo_educr.png" alt="">
				</div>
			</div>
		</section>
		<article id="intituciones">
			<div id="info_instit">
				<a href="http://portalunico.iaip.gob.hn/portal/index.php?portal=409" target="_blank" title="Instituto de Acceso a la Información Pública"><img src="../images/iap2.png" alt=""></a>
				<a href="#" target="_blank" title="Programa Presidencial de Becas"><img id="img_becas" src="../images/20202.png" alt=""></a>
				<a href="#" target="_blank" title="Comité de Control Interno"><img id="img_comite" src="../images/comite2.png" alt=""></a>
				<a href="#" target="_blank" title="Comité de Probidad y Ética"><img id="img_etica" src="../images/etica2.png" alt=""></a>
			</div>
		</article>
		<section id="cont_med">
			<div id="titu_2">
				Requisitos
			</div>
			<p>Para ser beneficiario de un crédito Educativo, se requiere:</p>
			<div id="info_niveles">
				<ul>
				    <li>Ser Hondureño por nacimiento.</li>
					<li>Tener una edad no mayor de 58 años, se exceptúan los docentes de nivel primario y medio, que deberán tener una edad no mayor de 48 años.</li>
					<li>Estar en el ejercicio pleno de sus derechos civiles.</li>
					<li>Estar aceptado en un centro de estudios acreditado y oficialmente reconocido.</li>
					<li>Haber pagado a EDUCREDITO por derecho a trámite administrativo del crédito.</li>
					<li>Firmar autorización irrevocable de deducción por planilla.</li>
				</ul>
			</div>
			<hr>
			<a name="req_fid"></a>
			<div id="titu_prod">
				Para los Aspirantes
			</div>
			<p>Los aspirantes a Crédito Educativo, deberán presentar sus solicitudes utilizando los formularios que EDUCREDITO proporciona, acompañado los siguientes documentos.</p>
			<div id="info_niveles">
				<ul>
				    <li>Copia de tarjeta de identidad y Registro Tributario Nacional (RTN)</li>
					<li>Partida de Nacimiento (Para menores de edad)</li>
					<li>Hoja de Vida (Curriculum Vitae)</li>
					<li>Certificacion de Estudios</li>
					<li>Copia del Título, Carta de Egresado o Acta de Graduación</li>
					<li>Historial Académico</li>
					<li>El programa Oficial de Estudios (Plan de Estudio)</li>
					<li>Constancia de Admisión de Matrícula</li>
					<li>Presupuesto de la Carrera del Centro de Estudios</li>
					<li>Programación de Desembolsos</li>
					<li>Constancia de trabajo con las deducciones</li>
					<li>Croquis de Ubicacíon de Residencia y del Lugar de Trabajo (descargar el croquis a través de Google Maps)</li>
				    <li>Copia de recibo Público, (Agua, Energía Eléctrica, Telefonía Fija, etc.)</li>
				    <li>Hoja de Autorización Irrevocable de Deducción por Planilla en base al Decreto Legislativo 29-87</li>
				    <li>No ser deudor o aval de algún crédito otorgado por EDUCREDITO</li>
				    <li>Comprobante de pago por gastos administrativos en EDUCREDITO, se exceptúa los empleados de EDUCREDITO</li>
				    <li>Comprobante de pago por consultas en la central de riesgos, se exceptúa los empleados de EDUCREDITO</li>
				    <li>Cualquier otro documentos que EDUCREDITO requiera</li>
				</ul>
			</div>
			</br>
		</section>
		<section id="cont_inter">
			<div id="info_inter">
				<div id="contenido_inter">
					<div id="titu_aval">
						Para los Avales
					</div>
					<p>Las personas naturales podran ser fiadores solidarios cuando cumplan los requisitos siguientes.</p>
					<div id="info_niveles">
						<ul>
							<li>Presentar formulario de información confidencial de aval, llenada completamente sin borrones ni manchones (nota: el aval debe
							ser menor de 58 años; si es docente, debe ser menor de 48 años).</li>
							<li>Copia de tarjeta de identidad y copia del R.T.N numérico.</li>
							<li>Constancia de trabajo con sus respectivas deducciones. (nota: el 30% del salario mensual debe destinarse para el pago de la cuota
							nivelada mensual del prestatario en caso de ser necesario pagar en determinado periodo).</li>
							<li>Croquis del lugar de residencia (descargarlo por GOOGLE MAPS).</li>
							<li>Copia de un recibo de servicios públicos (agua, luz, teléfono) reciente.</li>
							<li>En caso de que el aval alquile residencia, debe presentar copia del contrato de arrendamiento reciente.</li>
							<li>Presentar hoja de autorización irrevocable del aval, firmada y colocar huella digital (dedo índice mano derecha).</li>
						</ul>
					</div>
				</div>
			</div>
		</section>
		<a name="req_hipot"></a>
		<section id="productos">
			<div id="respo">
				<div id="titu_hipo">
					Para los Hipotecarios
				</div>
			<p id="descr">Si acompañas tu Solicitud de Crédito Educativo con una Garantía Hipotecaria, necesitaras presentar los siguientes documentos:</p>
			<div id="info_niveles">
				<ul>
					<li>Escritura Pública del propietario del bien inmueble.</li>
					<li>Tarjeta de Identidad y RTN del propietario del bien inmueble.</li>
					<li>Certificación de Libertad de Gravamen del bien inmueble.</li>
					<li>Informe de Avaluó del Bien Inmueble con fotografías (realizado por perito reconocido por la Comisión Nacional de Banca y Seguros (CNBS).</li>
					<div id="hipo_parr">
						<p>Aprobado el crédito hipotecario, presentará el bien inmueble e
						inscribirá la hipoteca a favor de EDUCREDITO en la oficina del
						Instituto de la Propiedad (IP) donde esté localizado el bien
						inmueble.</p>
						<p>Aprobado el crédito hipotecario, debe de adquirir un Seguro contra
						Daños para el bien inmueble en la Aseguradora de su elección
						mientras esté vigente el crédito educativo.</p>
					</div>
				</ul>	
			</div>
			</div>
			</br>
		</section>
		<section id="cont_inter2">
			<div id="info_inter2">
				<div id="contenido_inter2">
					<div id="titu_4">
						Garantias de los Créditos
					</div>
					<p>Los créditos educativos se garantizarán de la forma siguiente:</p>
					<table class="table-fill">
						<thead>
							<tr>
								<th class="text-left">Monto</th>
								<th class="text-left">Requisitos</th>
							</tr>
						</thead>
						<tbody class="table-hover">
							<tr>
								<td class="text-monto">L.15,000.00 a L.100, 000.00</td>
								<td class="text-left">1 - 2 Avales o Prenda Hipotecaria</td>
							</tr>
							<tr>
								<td class="text-monto">L.100, 001.00 a L.200, 000.00</td>
								<td class="text-left">2 - 3 Avales o Prenda Hipotecaria</td>
							</tr>
							<tr>
								<td class="text-monto">L.200, 001.00 a L.300, 000.00</td>
								<td class="text-left">3 Avales o Prenda Hipotecaria</td>
							</tr>
							<tr>
								<td class="text-monto">L.300, 001.00 a L.1, 000,000.00</td>
								<td class="text-left">Prenda Hipotecaria</td>
							</tr>
						</tbody>
					</table>
					<div id="respo">
						<div id="titu_desc">
							Descarga tu documentación
						</div>
						<div id="info_niveles">
							<ul>
								<li>
							    	<a href="../documents/Form_Unico.pdf" title="" target="_blank">Solicitud de crédito (Descargar) </a>
							    </li>
								<li>
									<a href="../documents/brochere.pdf" title="" target="_blank">Brochure Informativo (Descargar)</a>
								</li>
								<li>
							    	<a href="../documents/AUTORIZACION IRREVOCABLE  PRESTATARIO(A).pdf" title="" target="_blank">Autorización Irrevocable Prestatario(a) (Descargar) </a>
							    </li>
								<li>
									<a href="../documents/AUTORIZACION IRREVOCABLE AVAL.pdf" title="" target="_blank">Autorización Irrevocable Aval (Descargar)</a>
								</li>
							</ul>	
						</div>
					</div>
				</div>
			</div>
		</section>
		<div id="info_footer">
			<div id="con_footer">
				<div id="col1_footer">
					<div>
						<img src="../images/phone-call.png" alt=""> Teléfono
					</div>
					<a href="tel:+504-2239-4300" target="_top">+504-2239-4300/0439/5844</a>
					<div>
						<img src="../images/phone-call.png" alt=""> Teléfono
					</div>
					<a href="tel:+504-2239-8648" target="_top">+504-2239-8648/4299/4311</a>
					<div>
						<img src="../images/placeholder.png" alt=""> Ubicación
					</div>
					<a href="https://www.google.hn/maps/place/EDUCREDITO/@14.0865673,-87.1824749,17z/data=!3m1!4b1!4m5!3m4!1s0x8f6fa32af7e729b9:0x70f0e233535c310e!8m2!3d14.0865673!4d-87.1802862" title="" target="_blank">
						Colonia Florencia Norte
						<br>
						Contiguo al Colegio de Ingenieros Civiles de Honduras
						<br>
						Tegucigalpa, Honduras.
					</a>
				</div>
				<div id="col2_footer">
					<div>
						<img src="../images/mail.png" alt=""> E·mail
					</div>
					<a href="mailto:info@educredito.gob.hn" target="_top">info@educredito.gob.hn</a>
					<div>
						<img src="../images/face.png" alt=""> Facebook
					</div>
					<a href="http://www.facebook.com/educreditohonduras" target="_blank">fb.com/educreditohn</a>
					<div>
						<img src="../images/brochure-folded.png" alt=""> Información
					</div>
					<form action="enviar_info.php" method="post" accept-charset="utf-8">
						<input type="hidden" name="parameter" value="400">
						<input type="email" name="mail" value="" placeholder="Tu email para enviarte la información" required="">
						<div id="boton_enviar">
							<input type="submit" name="" value="Enviar">
						</div>
					</form>
				</div>
				<div id="col3_footer">
					<div>
						Nuestro Compromiso
					</div>
					<p>
						Fomentamos la educación con financiamiento educativo para miles de jóvenes que quieren estudiar en Honduras y en el extranjero.
					</p>
					<p>
						Queremos que todos puedan acceder a la educación nacional e internacional con la que siempre han soñado. 
					</p>
					<div>
						Más sobre Educredito
					</div>
					<ul>
					    <li><a href="../" title="">Inicio</a></li>
					    <li><a href="nosotros.php" title="">Nosotros</a></li>
					    <li><a href="financiamiento.php" title="">Financiamiento</a></li>
					    <li><a href="#" title="">Requisitos</a></li>
					    <li><a href="faqs.php" title="">Faqs</a></li>
					    <li><a href="" title="">Convenios</a></li>
					    <li><a href="#" title="">Becas</a></li>
					    <li><a href="contactenos.php" title="">Contacto</a></li>
					</ul><br>
				</div>
			</div>
		</div>
		<footer>
			<div id="cont_footer">
				<div id="copy">
					© Educredito 2017. Todos los derechos reservados.
				</div>
				<div id="aviso">
					<a href="">Aviso de privacidad.</a>&nbsp;&nbsp;&nbsp;<a href="">Atención a Usuarios.</a>
				</div>
				<div id="desing">
					Design by TIC´S Educredito.
				</div>
				
			</div>
		</footer>
	</div>
</body>
</html>
<?php 
include('funcion_mensajes_enviar.php');
	error_reporting(E_ALL ^ E_NOTICE);
	$mensaje=$_GET['mensaje'];
	if ($mensaje==1)
	{
		?>
			<script>
				window.location="#openModalm";
			</script>
		<?php
	}
?>